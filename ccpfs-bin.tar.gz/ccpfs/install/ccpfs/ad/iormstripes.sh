echo N1 strided for seqdlm
sh scripts/96x47008.sh 4 seqdlm
sleep 10
sh scripts/96x47008x4.sh 4 seqdlm
sleep 10
sh scripts/96x47008x16.sh 4 seqdlm
sleep 10

sh scripts/96x47008.sh 8 seqdlm
sleep 10
sh scripts/96x47008x4.sh 8 seqdlm
sleep 10
sh scripts/96x47008x16.sh 8 seqdlm
sleep 10

echo N1 strided for dlm-basic 
sh scripts/96x47008.sh 4 dlm-basic 
sleep 10
sh scripts/96x47008x4.sh 4 dlm-basic
sleep 10
sh scripts/96x47008x16.sh 4 dlm-basic
sleep 10

sh scripts/96x47008.sh 8 dlm-basic 
sleep 10
sh scripts/96x47008x4.sh 8 dlm-basic
sleep 10
sh scripts/96x47008x16.sh 8 dlm-basic
sleep 10



echo N1 strided for dlm-lustre 
sh scripts/96x47008.sh 4 dlm-basic
sleep 10
sh scripts/96x47008x4.sh 4 dlm-basic
sleep 10
sh scripts/96x47008x16.sh 4 dlm-basic
sleep 10

sh scripts/96x47008.sh 8 dlm-basic
sleep 10
sh scripts/96x47008x4.sh 8 dlm-basic
sleep 10
sh scripts/96x47008x16.sh 8 dlm-basic
sleep 10
