echo NBW with lock upgrade write size 64KB
sh scripts/lockupgrade.sh 64 NBW no
echo NBW with lock upgrade write size 256KB
sh scripts/lockupgrade.sh 256 NBW no
echo NBW with lock upgrade write size 1024KB
sh scripts/lockupgrade.sh 1024 NBW no

echo NBW without lock upgrade write size 64KB
sh scripts/lockupgrade.sh 64 NBW yes
echo NBW without lock upgrade write size 256KB
sh scripts/lockupgrade.sh 256 NBW yes
echo NBW without lock upgrade write size 1024KB
sh scripts/lockupgrade.sh 1024 NBW yes

echo PW write size 64KB
sh scripts/lockupgrade.sh 64 PW yes
echo PW write size 256KB
sh scripts/lockupgrade.sh 256 PW yes
echo PW write size 1024KB
sh scripts/lockupgrade.sh 1024 PW yes







