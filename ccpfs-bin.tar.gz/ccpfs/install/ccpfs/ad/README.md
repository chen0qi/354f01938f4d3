# The test scripts for tests in section Evaluation.
| script name | descriptions |
| ------- | -----------  |
| datasafety.sh	 | Subsection Micro Benchmark 1) Data Safety |
| dlm-breakdown.sh | Subsection Micro Benchmark 2) Early Grant and Early Revocation => Overhead breakdown |
| dlm-throughput.sh | Subsection Micro Benchmark 2) Early Grant and Early Revocation => Throughput
| dlm-upgrade.sh | Subsection Micro Benchmark 3) Lock Conversion => Lock upgrading
| dlm-downgrade.sh | Subsection Micro Benchmark 3) Lock Conversion => Lock downgrading 
| ior1stripe.sh | Subsection IOR Benchmark   1) Performance of a File with a Single Stripe
| iormstripes.sh | Subsection IOR Benchmark   2) Performance of a File with Multiple Stripes
| tileio.sh | Subsection Tile-IO Benchmark
| vpic-iof-1m.sh | Subsection PIC-IO Workload. <br> Used for Lustre and ccPFS as the backend of an IO forwarding software. <br> Each write contain 262,144 particles. |
|vpic-iof-256k.sh | Subsection PIC-IO Workload. <br> Run the benchmark with an IO frowarding software with Lustre or ccPFS as the backend. <br> Each write contains 65,536 particles. |
|vpic-iof-1m.sh | Subsection PIC-IO Workload. <br> Run the benchmark with an IO frowarding software with Lustre or ccPFS as the backend. <br> Each write contains 262,144 particles. |
|vpic-lustre-1m.sh | Subsection PIC-IO Workload. <br> Run the benchmark on Lustre. <br> Each write contains 262,144 particles. |
|vpic-lustre-256k.sh | Subsection PIC-IO Workload. <br> Run the benchmark on Lustre. <br> Each write contains 65,536 particles. |
| ior-singlenode.sh | IOR test that can be run on a single node for functional test. |
| tileio-singlenode.sh | tileIO test can be run on a single node for functional test. | 

# mpi hosts file.

hosts			: user for mpirun to select nodes to run.

# IB configuration
Cart RPC needs users choose which network to use by setting the environment variable OFI_INTERFACE. We set OFI_INTERFACE to ib0 accoriding our testbed. Users are reuqired to update the OFI_INTERFACE in the scripts if the IB interface name is not ib0. Please refer to https://github.com/daos-stack/daos/blob/master/src/cart/README.env for details.

# notes
To evaluate VPIC-IO workload, we use IO forwarding software that are used in the Sunway Taihulight supercomputer. We do not include the software in the package due to proprietary reasons. Instead, we present some [result logs](../../../../results/) that are generated during the tests.
