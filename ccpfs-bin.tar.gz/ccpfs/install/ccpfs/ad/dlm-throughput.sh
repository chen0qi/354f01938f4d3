echo NBW without early revocation 64KB
sh scripts/throughput.sh 64 NBW yes
echo NBW without early revocation 256KB
sh scripts/throughput.sh 256 NBW yes
echo NBW without early revocation 1024KB
sh scripts/throughput.sh 1024 NBW yes

echo NBW with early revocation 64KB
sh scripts/throughput.sh 64 NBW no 
echo NBW with early revocation 256KB
sh scripts/throughput.sh 256 NBW no 
echo NBW with early revocation 1024KB
sh scripts/throughput.sh 1024 NBW no 

echo PW without early revocation 64KB
sh scripts/throughput.sh 64  PW yes
echo PW without early revocation 256KB
sh scripts/throughput.sh 256 PW yes
echo PW without early revocation 1024KB
sh scripts/throughput.sh 1024 PW yes

echo PW with early revocation 64KB
sh scripts/throughput.sh 64 PW no 
echo PW with early revocation 256KB
sh scripts/throughput.sh 256 PW no 
echo PW with early revocation 1024KB
sh scripts/throughput.sh 1024 PW no 
