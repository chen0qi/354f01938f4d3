echo test tileIO with seqdlm with on 1 stripe on single node
sh scripts/tileio-singlenode.sh 1 seqdlm
echo test tileIO with seqdlm with on 2 stripes on single node
sh scripts/tileio-singlenode.sh 2 seqdlm

echo test tileIO with dlm-datatype with on 1 stripe on single node
sh scripts/tileio-singlenode.sh 1 dlm-datatype 
echo test tileIO with dlm-datatype with on 2 stripe on single node
sh scripts/tileio-singlenode.sh 2 dlm-datatype 
