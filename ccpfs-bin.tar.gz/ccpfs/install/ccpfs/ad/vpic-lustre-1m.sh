export HDF5_HOME=/home/ccpfs/install/
mpirun -f hosts -np 1280 ../bin/h5bench_write h5bench/h5bench.cfg.1m /mnt/lustre/test.h5
