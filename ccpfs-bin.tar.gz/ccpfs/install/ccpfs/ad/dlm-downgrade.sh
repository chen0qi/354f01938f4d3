echo NBW without lock downgrade write size 64KB
sh scripts/lockdowngrade.sh 64 BW yes
echo NBW without lock downgrade write size 256KB
sh scripts/lockdowngrade.sh 256 BW yes
echo NBW without lock downgrade write size 1024KB
sh scripts/lockdowngrade.sh 1024 BW yes

echo NBW with lock downgrade write size 64KB
sh scripts/lockdowngrade.sh 64 BW no 
echo NBW with lock downgrade write size 256KB
sh scripts/lockdowngrade.sh 256 BW no 
echo NBW with lock downgrade write size 1024KB
sh scripts/lockdowngrade.sh 1024 BW no 

echo PW without lock downgrade write size 64KB
sh scripts/lockdowngrade.sh 64 PW yes
echo PW without lock downgrade write size 256KB
sh scripts/lockdowngrade.sh 256 PW yes
echo PW without lock downgrade write size 1024KB
sh scripts/lockdowngrade.sh 1024 PW yes
