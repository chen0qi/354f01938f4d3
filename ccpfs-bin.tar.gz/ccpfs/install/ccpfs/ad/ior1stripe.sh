echo N1 segmented for seqDLM with 64KB write size
sh scripts/ior1stripe.sh 64k 2048M 1 seqdlm
echo N1 segmented for dlm-basic with 64KB write size
sh scripts/ior1stripe.sh 64k 2048M 1 dlm-basic 
echo N1 segmented for dlm-lustre with 64KB write size
sh scripts/ior1stripe.sh 64k 2048M 1 dlm-lustre 

echo N1 segmented for seqDLM
sh scripts/ior1stripe.sh 64k 2048M 1 seqdlm
sh scripts/ior1stripe.sh 256k 2048M 1 seqdlm
sh scripts/ior1stripe.sh 1024k 2048M 1 seqdlm

echo N1 strided for seqdlm
sh scripts/ior1stripe.sh 64k 64k 32768 seqdlm
sh scripts/ior1stripe.sh 256k 256k 8192 seqdlm
sh scripts/ior1stripe.sh 1024k 1024k 2048 seqdlm

echo N1 strided for dlm-basic 
sh scripts/ior1stripe.sh 64k 64k 32768 dlm-basic 
sh scripts/ior1stripe.sh 256k 256k 8192 dlm-basic
sh scripts/ior1stripe.sh 1024k 1024k 2048 dlm-basic

echo N1 strided for dlm-lustre 
sh scripts/ior1stripe.sh 64k 64k 32768 dlm-lustre 
sh scripts/ior1stripe.sh 256k 256k 8192 dlm-lustre
sh scripts/ior1stripe.sh 1024k 1024k 2048 dlm-lustre

