echo PW breakdown test
sh scripts/dlm-breakdown.sh 16 PW 
sh scripts/dlm-breakdown.sh 64 PW 
sh scripts/dlm-breakdown.sh 256 PW 
sh scripts/dlm-breakdown.sh 1024 PW 

echo NBW breakdown test
sh scripts/dlm-breakdown.sh 16 NBW 
sh scripts/dlm-breakdown.sh 64 NBW 
sh scripts/dlm-breakdown.sh 256 NBW 
sh scripts/dlm-breakdown.sh 1024 NBW 


