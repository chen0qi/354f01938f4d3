echo N1 strided for seqdlm 1 stripe and 4 process using one node 
sh scripts/ior-singlenode.sh 4 1 seqdlm
sleep 10
echo N1 strided for seqdlm 2 stripes and 4 process using one node 
sh scripts/ior-singlenode.sh 4 2 seqdlm

echo N1 strided for dlm-basic 1 stripe and 4 process using one node 
sh scripts/ior-singlenode.sh 4 1 dlm-basic
sleep 10
echo N1 strided for dlm-basic 2 stripes and 4 process using one node 
sh scripts/ior-singlenode.sh 4 2 dlm-basic

echo N1 strided for dlm-lustre 1 stripe and 4 process using one node 
sh scripts/ior-singlenode.sh 4 1 dlm-lustre
sleep 10
echo N1 strided for dlm-lustre 2 stripes and 4 process using one node 
sh scripts/ior-singlenode.sh 4 2 dlm-lustre

