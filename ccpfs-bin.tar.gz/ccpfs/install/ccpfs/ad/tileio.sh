echo test tileIO with seqdlm
sh scripts/tileio.sh 1 seqdlm
sh scripts/tileio.sh 4 seqdlm
sh scripts/tileio.sh 16 seqdlm

echo test tileIO with dlm-datatype 
sh scripts/tileio.sh 1 dlm-datatype 
sh scripts/tileio.sh 4 dlm-datatype 
sh scripts/tileio.sh 16 dlm-datatype 
