#!/bin/bash

MPIRUN='/usr/lib64/mpich-3.2/bin/mpirun'
CMD=" ../bin/ior -a ccpfs -G 1 -w -o ../ccpfs/file -t $1 -b $2 -s $3 -i 1"

ofi_domain=`ibstat 2>/dev/null|grep mlx|awk -F"'" '{print $2}'`
if [ -z "$ofi_domain" ];then
        echo $ofi_domain no infinibadn device found, cannot run test 
        exit -1
fi

killall ior
mkdir -p ../cfg
mkdir -p ../data
rm -fr ./debug*

${MPIRUN} -f hosts -np 16               \
		-env D_LOG_MASK=ERR			\
		-env CRT_TIMEOUT=1800			\
		-env CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
		-env OFI_INTERFACE=ib0		\
		-env OFI_DOMAIN=${ofi_domain}                   \
		-env CRT_CTX_SHARE_ADDR=0		\
		-env ccpfs_dir=/home/ccpfs/install/ccpfs/ccpfs         \
		-env ccpfs_data=/home/ccpfs/install/ccpfs/data         \
		-env ccpfs_cfg=/home/ccpfs/install/ccpfs/cfg           \
		-env lock_type=$4			\
		-env stripe_count=1 			\
		${CMD}
