#!/bin/bash

MPIRUN='/usr/lib64/mpich-3.2/bin/mpirun'
CMD=' ../bin/mpi-tile-io --nr_tiles_x 2 --nr_tiles_y 2 --sz_tile_x 20480 --sz_tile_y 20480 --overlap_x 100 --overlap_y 100 --sz_element 4 --filename ../ccpfs/tilefile --write_file'

ofi_domain=`ibstat 2>/dev/null|grep mlx|awk -F"'" '{print $2}'`
if [ -z "$ofi_domain" ];then
        echo $ofi_domain no infinibadn device found, cannot run test 
        exit -1
fi

${MPIRUN} -np 4               \
		-env D_LOG_MASK=ERR			\
		-env CRT_TIMEOUT=1800			\
		-env CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
		-env OFI_INTERFACE=ib0		\
		-env OFI_DOMAIN=${ofi_domain}                   \
		-env CRT_CTX_SHARE_ADDR=0		\
		-env ccpfs_dir=/home/ccpfs/install/ccpfs/ccpfs         \
		-env ccpfs_data=/home/ccpfs/install/ccpfs/data         \
		-env ccpfs_cfg=/home/ccpfs/install/ccpfs/cfg           \
		-env stripe_count=$1   \
		-env lock_type=$2   \
		${CMD}
