#!/bin/bash

MPIRUN='/usr/lib64/mpich-3.2/bin/mpirun'
CMD=" ../bin/ior -a ccpfs -G 1 -w -C -r -R -o ../ccpfs/file -t 1m -b 1m -s 1 -i 1"

ofi_domain=`ibstat 2>/dev/null|grep mlx|awk -F"'" '{print $2}'`
if [ -z "$ofi_domain" ];then
        echo $ofi_domain no infinibadn device found, cannot run test 
        exit -1
fi

${MPIRUN} -f hosts -np $1               \
	    -env ccpfs_dir=`pwd`/../ccpfs		\
	    -env ccpfs_data=`pwd`/../data		\
	    -env ccpfs_cfg=`pwd`/../cfg		\
	    -env D_LOG_MASK=ERR			\
	    -env CRT_TIMEOUT=1800			\
	    -env CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
	    -env OFI_INTERFACE=ib0		\
	    -env OFI_DOMAIN=${ofi_domain}                   \
	    -env CRT_CTX_SHARE_ADDR=0		\
	    -env stripe_count=$2 			\
	    ${CMD}
