#!/bin/bash

ORTERUN='/usr/lib64/openmpi3/bin/mpirun'
CMD=" ../bin/ior -a ccpfs -G 1 -w -C -r -R -o ../ccpfs/file -t 1m -b 1m -s 1 -i 1"

${ORTERUN} --allow-run-as-root			\
	   -hostfile hosts			\
 -mca routed direct    --bind-to none              \
	    -N 1 -np $1				\
	    -x ccpfs_dir=`pwd`/../ccpfs		\
	    -x ccpfs_data=`pwd`/../data		\
	    -x ccpfs_cfg=`pwd`/../cfg		\
	    -x D_LOG_MASK=ERR			\
	    -x CRT_TIMEOUT=1800			\
	    -x CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
	    -x OFI_INTERFACE=ib0		\
	    -x OFI_DOMAIN=mlx5_0			\
	    -x CRT_CTX_SHARE_ADDR=0		\
	    -x stripe_count=$2 			\
	    ${CMD}
