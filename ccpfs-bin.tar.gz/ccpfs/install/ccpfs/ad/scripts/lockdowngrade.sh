#!/bin/bash

MPIRUN='/usr/lib64/mpich-3.2/bin/mpirun'
CMD=" ../bin/dlm_test_mpi 5 $1"

ofi_domain=`ibstat 2>/dev/null|grep mlx|awk -F"'" '{print $2}'`
if [ -z "$ofi_domain" ];then
        echo $ofi_domain no infinibadn device found, cannot run test 
        exit -1
fi

${MPIRUN} -f hosts -np 16               \
		-x D_LOG_MASK=ERR			\
		-x CRT_TIMEOUT=1800			\
		-x CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
		-x OFI_INTERFACE=ib0		\
		-env OFI_DOMAIN=${ofi_domain}                   \
		-x CRT_CTX_SHARE_ADDR=0		\
		-x ccpfs_dir=/home/ccpfs/install/ccpfs/ccpfs         \
		-x ccpfs_data=/home/ccpfs/install/ccpfs/data         \
		-x ccpfs_cfg=/home/ccpfs/install/ccpfs/cfg           \
		-x perf_seqdlm=yes 			\
		-x stripe_count=2 			\
		-x dlm_mode=$2 			\
		-x no_dlm_conversion=$3             \
		${CMD}
