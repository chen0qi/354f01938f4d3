#!/bin/bash
ORTERUN='/usr/lib64/openmpi3/bin/mpirun'
CMD=" ../bin/dlm_test_mpi 1 1"

${ORTERUN} --allow-run-as-root			\
		-hostfile hosts			\
		-mca plm_rsh_no_tree_spawn 1 --bind-to none              \
		-N 1 -np 16				\
		-x D_LOG_MASK=ERR			\
		-x CRT_TIMEOUT=1800			\
		-x CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
		-x OFI_INTERFACE=ib0		\
		-x OFI_DOMAIN=mlx5_0			\
		-x CRT_CTX_SHARE_ADDR=0		\
		-x ccpfs_dir=/home/ccpfs/install/ccpfs/ccpfs         \
		-x ccpfs_data=/home/ccpfs/install/ccpfs/data         \
		-x ccpfs_cfg=/home/ccpfs/install/ccpfs/cfg           \
		-x stripe_count=$1 			\
		${CMD}
