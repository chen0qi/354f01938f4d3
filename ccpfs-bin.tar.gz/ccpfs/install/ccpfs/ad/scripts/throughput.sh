#!/bin/bash

MPIRUN='/usr/lib64/mpich-3.2/bin/mpirun'
CMD=" ../bin/dlm_test_mpi 3 $1"

ofi_domain=`ibstat 2>/dev/null|grep mlx|awk -F"'" '{print $2}'`
if [ -z "$ofi_domain" ];then
        echo $ofi_domain no infinibadn device found, cannot run test 
        exit -1
fi

killall ior
mkdir -p ../cfg
mkdir -p ../data
rm -fr ./debug*

${MPIRUN} -f hosts -np 16               \
		-env D_LOG_MASK=ERR			\
		-env CRT_TIMEOUT=1800			\
		-env CRT_PHY_ADDR_STR="ofi+verbs;ofi_rxm"	\
		-env OFI_INTERFACE=ib0		\
		-env OFI_DOMAIN=${ofi_domain}                   \
		-env CRT_CTX_SHARE_ADDR=0		\
		-env ccpfs_dir=/home/ccpfs/install/ccpfs/ccpfs         \
		-env ccpfs_data=/home/ccpfs/install/ccpfs/data         \
		-env ccpfs_cfg=/home/ccpfs/install/ccpfs/cfg           \
		-env perf_seqdlm=yes 			\
		-env stripe_count=1 			\
		-env no_dlm_conversion=yes             \
		-env client_print=yes 		\
		-env dlm_mode=$2 			\
		-env no_early_revocation=$3		\
		${CMD}
