export HDF5_HOME=/home/ccpfs/install/
mpirun -f hosts -np 1280 -env LD_PRELOAD=/home/ccpfs/install/lib/lwfs/liblwfs-booster.so.0.0.0  ../bin/h5bench_write h5bench.cfg.256k /mnt/ccpfs/test.h5
