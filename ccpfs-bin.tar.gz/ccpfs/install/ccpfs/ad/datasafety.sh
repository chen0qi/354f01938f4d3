echo io500 iorhard 16 clients 1stripe 
sh scripts/datasafety-ior-hard.sh 1	

echo io500 iorhard 16 clients 2stripe
sh scripts/datasafety-ior-hard.sh 2	

echo io500 iorhard 16 clients 4stripe
sh scripts/datasafety-ior-hard.sh 4	

echo overlapped write/read 1 stripe
sh scripts/datasafety-overlap.sh 1
echo overlapped write/read 2 stripe
sh scripts/datasafety-overlap.sh 2
