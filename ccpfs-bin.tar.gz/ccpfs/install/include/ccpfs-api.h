#ifndef _CCPFS_API_H_
#define _CCPFS_API_H_
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <inttypes.h>
#include <gurt/common.h>
#include <gurt/hash.h>
#include <hwloc.h>
#include <sys/uio.h>

/***************performance analysis *****************************************/
//#define PERF

#ifdef PERF
#define perf_start(name)                                \
        struct timeval start_##name, end_##name;        \
        gettimeofday(&start_##name, NULL)

#define perf_stop(name, to) do {                                                \
        gettimeofday(&end_##name, NULL);                                \
        printf("from %u to %lu %s : %lu\n", gccpfs.ccs_rank, (uint64_t)(to), #name,  \
               (end_##name.tv_sec - start_##name.tv_sec) * 1000000 +    \
               (end_##name.tv_usec - start_##name.tv_usec));            \
} while(0)
#else//perf
#define perf_start(name) do {;} while (0)
#define perf_stop(name, to) do {;} while (0)
#endif//end of perf

#if 1
#define tmdiff(end, start)      \
        (((end)->tv_sec - (start)->tv_sec) * 1000000 + (end)->tv_usec - (start)->tv_usec)

#define rec_start(name)                         \
        struct timeval rec_start_##name, rec_end_##name;        \
        gettimeofday(&rec_start_##name, NULL)
#define rec_end(name)                                           \
({                                                              \
        uint64_t ret;                                           \
        gettimeofday(&rec_end_##name, NULL);                    \
        ret = tmdiff(&rec_end_##name, &rec_start_##name);       \
        ret;                                                    \
})
#define tm_record(t)            gettimeofday(t, NULL)
static inline uint64_t tm_passed(struct timeval *start)
{
	struct timeval end;

	gettimeofday(&end, NULL);
	return tmdiff(&end, start);
}
#else

#define tmdiff(start, end)                                           \
({                                                              \
        uint64_t ret = 1;                                           \
        ret;                                                    \
})

#define rec_start(name) do {;}while(0) 
#define rec_end(name)                                           \
({                                                              \
        uint64_t ret = 1;                                           \
        ret;                                                    \
})

#define tm_record(t)  do {;}while (0)
static inline uint64_t tm_passed(struct timeval *start)
{
	return 1;
}
#endif
enum LOCK_MODE {
	/* basic mode */
	LM_WRONLY	= 0x00000001,
	LM_RDONLY	= 0x00000002,
	LM_CONCURRENT	= 0x00000004,
	LM_BLOCK	= 0x00000008,
	LM_EXCLUSIVE	= 0x00000010,
	LM_SNAP		= 0x00000020,
	LM_TRANSIENT	= 0x00000040,
	/* intent */
	LM_APPEND	= 0x00000100,
	LM_TRUNC	= 0x00000200,
	LM_GLIMPSE	= 0x00000400,
	LM_REBALANCE	= 0x00000800,
	LM_RESTRIPE	= 0x00001000,
	LM_UNLINK	= 0x00002000,
};

#define LM_MASK (LM_WRONLY|LM_RDONLY|LM_CONCURRENT|LM_EXCLUSIVE|LM_BLOCK|LM_SNAP|LM_TRANSIENT)

#define LM_SNAPFLG (LM_SNAP | LM_REBALANCE | LM_RESTRIPE)
#define LM_EW (LM_EXCLUSIVE|LM_WRONLY)
#define LM_BW (LM_BLOCK|LM_WRONLY)
#define LM_PW (LM_WRONLY)
#define LM_CW (LM_CONCURRENT|LM_WRONLY)
#define LM_PR (LM_RDONLY)
#define LM_SW (LM_SNAP|LM_WRONLY)

#define TILE_X 8 /* used for tileIO test */
#define TILE_Y 8 /* used for tileIO test */

#define MAX_STRIPE_COUNT 32
#define PAGE_SIZE (1024*4)
#define STRIPE_SIZE	(1024*1024)	/*stripe size is 1MB */
#define PAGE_MAX_NR	256
#define READ_PAR 16
#define WRITE_PAR 16
#define CL_PAR_RATIO 16
#define ALIGN(pos)	((pos)/PAGE_SIZE*PAGE_SIZE)
#define ALIGNLOFF(pos)	((pos) % PAGE_SIZE)

enum IO_OP {
        IO_WRITE = 1,
        IO_READ,
        IO_REPLY,
};

struct rw_iovec {
	char *buf;
	int64_t start;
	int64_t end;
};

extern bool g_no_early_revocation;
extern bool g_no_dlm_conversion;
extern bool g_perf_seqdlm;
extern bool g_dlm_lustre;
extern bool g_is_dlm_func;
extern bool g_is_dlm_basic;
extern uint32_t g_stripe_count;
extern bool g_no_async_flush;
extern uint32_t gdlm_mode;
extern bool gprint_locktime;
extern bool gprint_cl;

extern uint32_t gccpfs_rank;
extern uint32_t gccpfs_grp_size;
extern uint32_t gdlm_mode;

static inline uint64_t stripe_fid(uint64_t fid, uint32_t stripe_idx)
{
	if (g_stripe_count == 1)
		return fid;

	return ((fid & (0xffffffffffffff)) << 8)|(stripe_idx & 0xff);
}

int cc_cpubind_to_core(int core_idx);
int ccpfs_init(int argc, char *argv[], char *cfg_path, char *data_path,
	       int32_t master_count, int32_t work_count, int32_t core_off);
int ccpfs_fini(void);
void *cdlm_lock(uint64_t fid, uint64_t start, uint64_t end, uint32_t mode, uint64_t *fsize);
int cdlm_unlock(uint64_t fid, void *dlmp, uint64_t start, uint64_t end, uint32_t mode);
ssize_t cdlm_append(int fd, const void *buf, size_t count);
int cdlm_get_size(uint64_t fid, uint64_t *fsize);

/* fs interface */
int ccpfs_open(const char *pathname, int flags, ...);
int ccpfs_close(int fd);
ssize_t ccpfs_write(int fd, const void *buf, size_t count);
ssize_t ccpfs_pwrite(int fd, const void *buf, size_t count, off_t offset);
ssize_t ccpfs_append(int fd, const void *buf, size_t count);
ssize_t ccpfs_read(int fd, void *buf, size_t count);
int64_t ccpfs_pread(int fd, void *buf, int64_t count, int64_t offset);
int ccpfs_truncate(const char *path, off_t length);
int ccpfs_ftruncate(int fd, off_t length);
int ccpfs_stat(const char *pathname, struct stat *buf);
int ccpfs_lstat(const char *pathname, struct stat *buf);
int ccpfs_fstat(int fd, struct stat *buf);
off_t ccpfs_lseek(int fd, off_t offset, int whence);
int ccpfs_fsync(int fd);
int ccpfs_unlink(const char *pathname);
void *ccpfs_lock(uint64_t fd, uint64_t start, uint64_t end, uint32_t mode, uint64_t *fsize);
int ccpfs_unlock(uint64_t fd, void *dlmp, uint64_t start, uint64_t end, uint32_t mode);

/* support noncontigous write and read */
uint64_t ccpfs_write_iov(int fd, struct rw_iovec *fiov, uint32_t fiov_count);
uint64_t ccpfs_read_iov(int fd, struct rw_iovec *fiov, uint32_t fiov_count);

//for test
void cart_pingpong(int tgt_idx, bool payload);
void perf_write(uint32_t rank, int page_count);
void rdma_perf_write(int num_pages);
void rdma_perf_read(int num_pages);

struct array {                                                                                                                   
	int64_t off;    /* array offset */
	int64_t len;    /* array length */
	int64_t count;/* how many subarray */
	int64_t size;/* total array size */
	int32_t rank;
};
bool is_datatype_lock_conflict_with_stripe(struct array *A, struct array *B, uint32_t stripe_idx);


static inline uint32_t compute_checksum(const char *buf, size_t size)
{       
        int  ret = -1;
        char *checksum_buf = NULL;
        uint32_t checksum = 0;
        
        checksum_buf = (char *)(&checksum);
        checksum_buf [0] = 0xba;
        checksum_buf [1] = 0xbe;
        checksum_buf [2] = 0xb0;
        checksum_buf [3] = 0x0b;
        
        for (ret = 0; ret < (size - 4); ret += 4) {
                checksum_buf[0] ^= (buf[ret]);
                checksum_buf[1] ^= (buf[ret + 1] << 1) ;
                checksum_buf[2] ^= (buf[ret + 2] << 2);
                checksum_buf[3] ^= (buf[ret + 3] << 3);
        }
        
        for (ret = 0; ret <= (size % 4); ret++) { 
                checksum_buf[ret] ^= (buf[(size - 4) + ret] << ret);
        }
	//printf("size %ld\n", size);
        return checksum;
}

#define TPL_NUM	1
#endif /* _CCPFS_API_H_ */

