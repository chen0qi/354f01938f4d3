#!/bin/bash

yum install -y hwloc hwloc-devel libyaml gcc libatomic mpich-3.2-3.2 mpich-3.2-autoload mpich-3.2-devel git gcc-c++ libtool boost-devel cmake libuuid-devel openssl-devel libyaml-devel libibverbs
