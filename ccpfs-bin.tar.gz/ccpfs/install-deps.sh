yum install -y hwloc hwloc-devel libyaml gcc libatomic openmpi3 openmpi3-devel git gcc-c++ libtool boost-devel cmake libuuid-devel openssl-devel libyaml-devel libibverbs 
